# Offline Voiceover Package & Audio Engine Integration

Pre-generate all factually accurate Apollo 11 dialogue lines as optimized MP3 audio files using Gemini TTS with Neil Armstrong's male voice persona, package them into a dedicated standalone offline zip archive (`nobotara-voiceovers-offline.zip`), configure the 3D game audio engine for automatic local audio file priority with zero cloud dependency, and provide an export flow targeting `/Volumes/KINGSTON/Nobotara/NobotaraGame/public/assets`.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following decisions were confirmed in Phase 1 clarification:
> - **Package Format**: Standalone voiceover audio zip archive (`nobotara-voiceovers-offline.zip`), allowing you to download and extract audio directly into your game's assets folder without bloating the base code repository.
> - **Audio Compression**: MP3 format (128 kbps CBR, mono 44.1 kHz) for compact size (~1.2 MB total package), instant playback latency, and universal macOS/Safari/Chrome compatibility.
> - **Target Local Path**: `/Volumes/KINGSTON/Nobotara/NobotaraGame/public/assets/audio/voiceovers/`.

---

## 1. Overview & Core Concept

### What It Does
- Enables 100% offline gameplay with authentic Neil Armstrong spoken voice acting, even when running the game from a USB drive without an internet connection or Gemini API keys.
- Pre-renders all 8 scripted mission dialogue clips into MP3 audio files using Gemini TTS (`gemini-3.8-flash-lite-tts` with the `Fenrir` deep, grounded male astronaut persona).
- Upgrades `apolloAudio.ts` with a **Local Audio Asset Resolver** that checks for static local MP3 files before falling back to online TTS or browser speech synthesis.
- Provides a dedicated 1-click **Download Offline Voiceovers** action in the Export Modal with automatic macOS Terminal commands configured for `/Volumes/KINGSTON/Nobotara/NobotaraGame/public/assets`.

### Target Audience & Persona
- Students, museum visitors, and educators running the simulation offline or in classroom settings without reliable high-speed internet.

---

## 2. User Experience & Visual Design

### Key User Flows

```
┌────────────────────────────────────────────────────────────────────────┐
│                        OFFLINE VOICEOVER FLOW                          │
│                                                                        │
│  [ Title Screen / HUD ]                                                │
│         │                                                              │
│         ▼                                                              │
│  [ Export Modal ] ──► "Offline Voiceovers (.ZIP)" Card                 │
│         │                     │                                        │
│         │                     ▼ Click "Download Voiceover Pack"        │
│         │             Streams nobotara-voiceovers-offline.zip          │
│         │                     │                                        │
│         ▼                     ▼                                        │
│  [ Copy macOS Command ] ──► Extracts to /Volumes/KINGSTON/.../assets/  │
│                               │                                        │
│                               ▼                                        │
│  [ Local Offline Play ] ──► apolloAudio detects /assets/audio/*.mp3    │
│                             Plays Neil Armstrong audio + Quindar beeps │
└────────────────────────────────────────────────────────────────────────┘
```

### Visual Identity & Interface Updates
- **Voiceover Pack Card in Export Modal**:
  - Dark slate obsidian panel (`bg-slate-950/80 border-amber-500/40`) with a gold microphone icon (`Mic`).
  - Badge: `OFFLINE ASSET PACK · 8 MP3 CLIPS · ~1.2 MB`.
  - Primary button: `DOWNLOAD VOICEOVERS (.ZIP)` with in-browser blob streaming.
  - Dedicated macOS Terminal One-Liner Box with copy-to-clipboard button:
    ```bash
    mkdir -p "/Volumes/KINGSTON/Nobotara/NobotaraGame/public/assets/audio/voiceovers" && unzip -o ~/Downloads/nobotara-voiceovers-offline.zip -d "/Volumes/KINGSTON/Nobotara/NobotaraGame/public/assets/audio/voiceovers"
    ```
- **HUD Audio Status Indicator**:
  - Subtle indicator in the dialogue subtitle box displaying `SOURCE: LOCAL OFFLINE ASSET` when playing pre-rendered clips, confirming zero network calls.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Standalone Voiceover Pack vs. Bundled Code Archive**
  - *Chosen Approach*: Deliver voiceovers as a dedicated standalone archive (`nobotara-voiceovers-offline.zip`) while also placing them into `public/assets/audio/voiceovers/` in the dev workspace so subsequent full-project exports can include them if desired.
  - *Why*: Allows rapid updating of voiceover files without re-downloading code, matching the user's preference.
- **Decision 2: Audio Format Selection (MP3 vs. WAV)**
  - *Chosen Approach*: Standard MP3 encoded at 128 kbps mono.
  - *Why*: 8 clips take under ~1.2 MB total compared to ~15 MB for uncompressed WAV, ensuring rapid download and minimal memory usage on USB flash drives.
- **Decision 3: Tiered Audio Playback Hierarchy**
  - *Chosen Approach*:
    1. **Tier 1 (Offline Primary)**: Try loading local `/assets/audio/voiceovers/{clipId}.mp3`.
    2. **Tier 2 (Online Fallback)**: If running on dev server and clip not found, call server `/api/narrator` with Gemini TTS.
    3. **Tier 3 (Emergency Fallback)**: Client Web Speech API with radio-bandpass filter.
  - *Why*: Guarantees zero silence and unbroken gameplay regardless of network state or missing files.

---

## 4. Technical Architecture & Data Strategy

### Component Architecture & Audio Flow

```
┌────────────────────────────────────────────────────────────────────────┐
│                        AUDIO ARCHITECTURE                              │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│   src/App.tsx / InspectionModal.tsx                                    │
│         │                                                              │
│         ▼                                                              │
│   apolloAudio.speakDialogue(text, speaker, onEnd, clipId?)             │
│         │                                                              │
│         ├──► [Step 1] Check Pre-rendered Local MP3                     │
│         │       Path: /assets/audio/voiceovers/{clipId}.mp3            │
│         │       Success ──► HTML5 Audio Element                        │
│         │                     │                                        │
│         │                     ├──► Quindar Intro Beep (2524 Hz)        │
│         │                     ├──► Audio Bandpass Node (300Hz-3.4kHz)  │
│         │                     └──► Quindar Outro Beep (2475 Hz)        │
│         │                                                              │
│         └──► [Step 2] (If 404 / Missing)                               │
│                 └──► Fallback to /api/narrator (Gemini TTS)            │
│                         └──► Web Speech API Fallback                   │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

### Scripted Voiceover Clip Registry

| Clip ID | Speaker | Scripted Dialogue | Duration |
| :--- | :--- | :--- | :--- |
| `intro_neil` | Neil Armstrong | "Hey, Neil Armstrong here. On July 16, 1969, we rode a Saturn V built from math, sweat, and nerve. 384,000 km to test physics where mistakes could kill. We didn’t just chase a rock in the sky; we went to learn what people can do when they dare." | ~15s |
| `descent_stage_neil` | Neil Armstrong | "This is the Eagle’s descent stage. It helped the Lunar Module land on the Moon. The ascent stage carried me and Aldrin back into lunar orbit, while the descent stage remained behind." | ~10s |
| `descent_stage_scientific` | Scientific Voice | "The Lunar Module was built in two distinct stages. The descent stage contained the throttleable rocket engine, landing gear, and propellant tanks. Since weight was critical for orbital rendezvous, only the lightweight ascent stage lifted off to return to Earth." | ~13s |
| `retroreflector_neil` | Neil Armstrong | "Not everything left behind became inactive. Apollo 11 astronauts placed this laser retroreflector. Scientists on Earth can send laser pulses toward it and measure the returning light to study the distance between Earth and the Moon." | ~12s |
| `retroreflector_scientific` | Scientific Voice | "Observatories in Texas, Hawaii, and France still bounce high-energy pulsed lasers off this Apollo 11 reflector. By timing the ~2.5 second round-trip with picosecond accuracy, scientists proved the Moon is drifting away at 3.8 cm per year." | ~14s |
| `plaque_neil` | Neil Armstrong | "This plaque commemorates humanity’s first crewed lunar landing. It carries a message of peace from Earth. A message left behind for history to remember." | ~9s |
| `plaque_scientific` | Scientific Voice | "Engraved on stainless steel to withstand cosmic radiation and 300°C temperature swings: 'HERE MEN FROM THE PLANET EARTH FIRST SET FOOT UPON THE MOON JULY 1969 A.D. WE CAME IN PEACE FOR ALL MANKIND.'" | ~11s |
| `puzzle_complete_neil` | Neil Armstrong | "Good work, explorer. You understand why we left these pieces behind: for science, for survival, and for peace. The lunar surface keeps our story safe." | ~9s |
| `outro_voyager` | Neil Armstrong | "The footprints at Tranquility Base proved that humanity could leave Earth. But our journey didn't stop at the Moon. We aimed further—beyond the planets, into interstellar space." | ~10s |

### Server Endpoints & Packaging
- **`server.ts`**:
  - Add `/api/generate-all-voiceovers`: Utility script that iterates over the clip registry and fetches high-fidelity Gemini TTS audio using `gemini-3.8-flash-lite-tts` (`Fenrir` for Neil, `Puck` for Science), saving them to `public/assets/audio/voiceovers/*.mp3`.
  - Add `/api/download-voiceovers-zip`: Serves `nobotara-voiceovers-offline.zip` with attachment headers and cache control.
  - Add in-memory Base64 fallback `/api/download-voiceovers-base64` to prevent iframe download redirection.
