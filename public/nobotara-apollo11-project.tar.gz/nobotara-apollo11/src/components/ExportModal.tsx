import React, { useState } from 'react';
import { X, Download, HardDrive, Check, Copy, Folder, Terminal, Sparkles, FileArchive, AlertCircle, RefreshCw, Volume2, Music } from 'lucide-react';
import { downloadProjectArchive, downloadVoiceoverArchive, ArchiveFormat } from '../utils/downloadHelper';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose }) => {
  const [copiedZip, setCopiedZip] = useState(false);
  const [copiedTar, setCopiedTar] = useState(false);
  const [copiedVoice, setCopiedVoice] = useState(false);
  const [downloadingFormat, setDownloadingFormat] = useState<ArchiveFormat | 'voiceover' | null>(null);
  const [downloadStatus, setDownloadStatus] = useState<string>('');

  if (!isOpen) return null;

  const targetVoiceoverPath = '/Volumes/KINGSTON/Nobotara/NobotaraGame/public/assets';
  const targetProjectPath = '/Volumes/KINGSTON/Nobotara/NobotaraGame';
  
  const voiceCommand = `mkdir -p "/Volumes/KINGSTON/Nobotara/NobotaraGame/public/assets" && unzip -o ~/Downloads/nobotara-voiceovers-offline.zip -d "/Volumes/KINGSTON/Nobotara/NobotaraGame/public/assets"`;
  const tarCommand = `mkdir -p "${targetProjectPath}" && tar -xzf ~/Downloads/nobotara-apollo11-project.tar.gz -C "${targetProjectPath}" --strip-components=1 && cd "${targetProjectPath}" && npm install && npm run dev`;
  const zipCommand = `mkdir -p "${targetProjectPath}" && unzip -o ~/Downloads/nobotara-apollo11-project.zip -d "${targetProjectPath}" && cd "${targetProjectPath}" && npm install && npm run dev`;

  const handleDownloadProject = async (format: ArchiveFormat) => {
    try {
      setDownloadingFormat(format);
      await downloadProjectArchive(format, (status) => setDownloadStatus(status));
    } catch (err: any) {
      setDownloadStatus(`Download failed: ${err?.message || 'Check connection'}`);
    } finally {
      setTimeout(() => {
        setDownloadingFormat(null);
        setDownloadStatus('');
      }, 4000);
    }
  };

  const handleDownloadVoiceovers = async () => {
    try {
      setDownloadingFormat('voiceover');
      await downloadVoiceoverArchive((status) => setDownloadStatus(status));
    } catch (err: any) {
      setDownloadStatus(`Download failed: ${err?.message || 'Check connection'}`);
    } finally {
      setTimeout(() => {
        setDownloadingFormat(null);
        setDownloadStatus('');
      }, 4000);
    }
  };

  const handleCopy = (text: string, type: 'zip' | 'tar' | 'voice') => {
    navigator.clipboard.writeText(text);
    if (type === 'zip') {
      setCopiedZip(true);
      setTimeout(() => setCopiedZip(false), 2500);
    } else if (type === 'tar') {
      setCopiedTar(true);
      setTimeout(() => setCopiedTar(false), 2500);
    } else {
      setCopiedVoice(true);
      setTimeout(() => setCopiedVoice(false), 2500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border border-slate-700/80 rounded-xl max-w-2xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950/70">
          <div className="flex items-center gap-2.5">
            <HardDrive className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="text-sm md:text-base font-bold text-slate-100 font-mono-num uppercase tracking-wider">
                Export to Local PC / Kingston USB Drive
              </h2>
              <p className="text-xs text-slate-400 font-mono-num">
                Target: {targetProjectPath}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-xs md:text-sm text-slate-300 overflow-y-auto">
          {/* Section 1: Offline Voiceovers Pack */}
          <div className="bg-gradient-to-r from-amber-950/40 via-slate-950/70 to-slate-950/70 border border-amber-500/50 rounded-xl p-4 space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Volume2 className="w-4 h-4 text-amber-400" />
                  <span className="font-bold text-slate-100 text-sm">Offline Voiceover Audio Pack</span>
                  <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded font-mono-num font-bold">
                    9 MP3 CLIPS · 2.1 MB
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Pre-rendered authentic Neil Armstrong male voice lines and Scientific explanations in MP3 format. When placed in your assets folder, the game plays them 100% offline without needing internet or API keys.
                </p>
                <div className="text-[11px] font-mono-num text-amber-300/80">
                  Target Destination: <code className="bg-slate-900 px-1.5 py-0.5 rounded text-amber-300 font-bold">{targetVoiceoverPath}</code>
                </div>
              </div>
              <button
                onClick={handleDownloadVoiceovers}
                disabled={downloadingFormat !== null}
                className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-amber-500 hover:bg-amber-400 disabled:bg-slate-700 text-slate-950 disabled:text-slate-400 font-bold rounded-lg shadow-lg hover:shadow-amber-500/25 text-xs transition-all duration-150 shrink-0 cursor-pointer"
              >
                {downloadingFormat === 'voiceover' ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Download className="w-4 h-4" />
                )}
                <span>{downloadingFormat === 'voiceover' ? 'PREPARING...' : 'DOWNLOAD VOICEOVERS (.ZIP)'}</span>
              </button>
            </div>

            {/* Quick Unpack Voiceovers Command */}
            <div className="bg-slate-950/90 border border-slate-800 rounded-lg p-2.5 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-400 font-mono-num flex items-center gap-1.5">
                  <Terminal className="w-3 h-3 text-amber-400" />
                  <span>Unpack Voiceovers to Kingston Drive:</span>
                </span>
                <button
                  onClick={() => handleCopy(voiceCommand, 'voice')}
                  className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[10px] transition-colors"
                >
                  {copiedVoice ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedVoice ? 'COPIED!' : 'COPY'}</span>
                </button>
              </div>
              <pre className="text-[11px] font-mono-num text-amber-300 bg-black/60 p-2 rounded overflow-x-auto whitespace-pre-wrap leading-relaxed select-all">
                {voiceCommand}
              </pre>
            </div>
          </div>

          {/* Section 2: Full Game Source Code Project */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-xs uppercase tracking-wider text-slate-200 font-mono-num flex items-center gap-1.5">
                <Folder className="w-4 h-4 text-slate-400" />
                <span>Full Game Source Code Archive</span>
              </h3>
              <span className="text-[11px] text-slate-400 font-mono-num">
                Vite + React + Three.js Engine + Express
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* TAR.GZ Card (Mac Preferred) */}
              <div className="bg-slate-950/70 border border-emerald-900/40 rounded-lg p-3.5 flex flex-col justify-between gap-3">
                <div>
                  <div className="flex items-center gap-1.5 font-bold text-emerald-400 text-sm">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    <span>Native macOS .TAR.GZ</span>
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono-num mt-1">
                    Recommended for Mac: Native POSIX archive, double-click or terminal extract (~88 KB)
                  </div>
                </div>
                <button
                  onClick={() => handleDownloadProject('targz')}
                  disabled={downloadingFormat !== null}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-700 text-slate-950 disabled:text-slate-400 font-bold rounded-lg shadow-lg hover:shadow-emerald-500/20 text-xs transition-all duration-150 cursor-pointer"
                >
                  {downloadingFormat === 'targz' ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Download className="w-4 h-4" />
                  )}
                  <span>{downloadingFormat === 'targz' ? 'PREPARING...' : 'DOWNLOAD PROJECT (.TAR.GZ)'}</span>
                </button>
              </div>

              {/* ZIP Card */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between gap-3">
                <div>
                  <div className="flex items-center gap-1.5 font-bold text-slate-100 text-sm">
                    <FileArchive className="w-4 h-4 text-amber-400" />
                    <span>Verified Project .ZIP</span>
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono-num mt-1">
                    Universal ZIP archive with explicit Unix directory nodes & 644 permissions (~99 KB)
                  </div>
                </div>
                <button
                  onClick={() => handleDownloadProject('zip')}
                  disabled={downloadingFormat !== null}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-lg text-xs transition-all duration-150 cursor-pointer border border-slate-700"
                >
                  {downloadingFormat === 'zip' ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Download className="w-4 h-4" />
                  )}
                  <span>{downloadingFormat === 'zip' ? 'PREPARING...' : 'DOWNLOAD PROJECT (.ZIP)'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Download progress status */}
          {downloadStatus && (
            <div className="text-center font-mono-num text-xs text-amber-300 bg-amber-950/40 py-1.5 px-3 rounded border border-amber-800/40 animate-fade-in">
              {downloadStatus}
            </div>
          )}

          {/* Terminal Options for Game Setup */}
          <div className="space-y-2">
            <div className="text-[11px] uppercase font-mono-num font-bold text-slate-400">
              One-Step Game Setup & Launch Terminal Commands:
            </div>
            
            {/* TAR.GZ Command (Mac Preferred) */}
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-2.5 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-emerald-400 font-mono-num flex items-center gap-1">
                  <Terminal className="w-3 h-3" />
                  <span>Option A (TAR.GZ — Recommended for Mac):</span>
                </span>
                <button
                  onClick={() => handleCopy(tarCommand, 'tar')}
                  className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[10px] transition-colors"
                >
                  {copiedTar ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedTar ? 'COPIED!' : 'COPY'}</span>
                </button>
              </div>
              <pre className="text-[11px] font-mono-num text-emerald-300 bg-black/60 p-2 rounded overflow-x-auto whitespace-pre-wrap leading-relaxed select-all">
                {tarCommand}
              </pre>
            </div>

            {/* ZIP Command */}
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-2.5 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-amber-400 font-mono-num flex items-center gap-1">
                  <Terminal className="w-3 h-3" />
                  <span>Option B (ZIP):</span>
                </span>
                <button
                  onClick={() => handleCopy(zipCommand, 'zip')}
                  className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[10px] transition-colors"
                >
                  {copiedZip ? <Check className="w-3 h-3 text-amber-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedZip ? 'COPIED!' : 'COPY'}</span>
                </button>
              </div>
              <pre className="text-[11px] font-mono-num text-amber-300 bg-black/60 p-2 rounded overflow-x-auto whitespace-pre-wrap leading-relaxed select-all">
                {zipCommand}
              </pre>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/70 flex justify-between items-center shrink-0">
          <span className="text-[11px] text-slate-500 font-mono-num flex items-center gap-1.5">
            <Music className="w-3.5 h-3.5 text-amber-400" />
            <span>Voiceovers include Neil Armstrong radio dialogue & Apollo scientific narrations</span>
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-lg text-xs transition-colors cursor-pointer"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
